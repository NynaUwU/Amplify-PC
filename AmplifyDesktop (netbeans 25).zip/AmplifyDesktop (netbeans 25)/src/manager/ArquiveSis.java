package manager;

import java.io.*;
import java.util.ArrayList;

public class ArquiveSis {
    // Método para salvar objetos no arquivo
    public static boolean SaveCs(String nomePlaylist,ArrayList products) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(nomePlaylist+".dat"))) {
            oos.writeObject(products);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    // Método para ler objetos do arquivo
    public static ArrayList LoadCs(String nomePlaylist) {
        ArrayList listaproducts = new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(nomePlaylist+".dat"))) {
          listaproducts = (ArrayList) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }  
        return listaproducts;
    }
    
    public static boolean itExists(String nomePlaylist) {
        File folder = new File(nomePlaylist+".dat");
        if (folder.exists()) {
            return true;
        }else{
            return false;
        }
        
    }
}
