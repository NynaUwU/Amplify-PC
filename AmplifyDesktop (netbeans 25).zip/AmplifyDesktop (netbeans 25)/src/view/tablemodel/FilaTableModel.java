    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view.tablemodel;

import com.example.musicplayer.Musica;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;


public class FilaTableModel extends AbstractTableModel {

    private ArrayList<Musica> lista;

    public FilaTableModel(ArrayList<Musica> lista) {
        this.lista = lista;
    }

    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return 3;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Musica p = lista.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return rowIndex;
            case 1:
                return p.getNome();
            case 2:
                return p.getDuracaoStr();
            default:
                return "NONE";
        }
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "ID";
            case 1:
                return "Nome";
            case 2:
                return "Tempo";
            default:
                return "NONE";
        }
    }

    public Musica getMusica(int linha) {
        return lista.get(linha);
    }
}