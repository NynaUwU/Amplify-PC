package manager;

import com.example.musicplayer.Musica;

import javafx.scene.media.MediaPlayer;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import javafx.scene.media.Media;
import javafx.util.Duration;

public class playerManager implements Runnable {

    private boolean playing = false;
    private Random random = new Random();
    public MediaPlayer mediaPlayer;
    private List<Musica> oldListaPlayingNow;
    private List<Musica> listaPlayingNow;
    private Media media;
    private int mode = 1;
    // 1 = go
    // 2 = go repeating
    // 3 = shuffle
    // 4 = real shuffle
    // 5 = repeat one
    public Musica music;

    public playerManager() {

        
        String source = null;

        media = new Media(source);

        mediaPlayer = new MediaPlayer(media);
    }

    @Override
    public void run() {

        if (mediaPlayer == null) {
            mediaPlayer = new MediaPlayer(media);
        }

        if (mediaPlayer != null) {
            mediaPlayer.setOnEndOfMedia(() -> {
                nextMediaPlayer();
            });
        }
    }

    public boolean setMusicPlay(Musica music, List<Musica> listaPlayingNow, int mode) throws IOException {

        this.listaPlayingNow = listaPlayingNow;
        this.oldListaPlayingNow = listaPlayingNow;
        this.music = music;
        this.mode = mode;
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            StopPlayer();

            File file = new File(music.getArquivo());

            mediaPlayer.stop();

            String source = null;

            try {
                source = file.toURI().toURL().toString();
            } catch (Exception e) {
            }

            media = new Media(source);

            playing = true;
            return true;
        } else {
            playing = false;
            return false;
        }

    }

    public void playPausePlayback() {

        if (mediaPlayer != null && mediaPlayer.getStatus()==MediaPlayer.Status.PLAYING) {
            mediaPlayer.pause();
            playing = false;
        } else if (mediaPlayer != null) {
            mediaPlayer.play();

            playing = true;
        }
    }

    public void prevMediaPlayer() {
        if (listaPlayingNow != null) {
            int here = listaPlayingNow.indexOf(music);

            switch (mode) {
                case 1:
                    if (here == 0) {
                        StopPlayer();
                    } else {
                        here--;
                        try {

                            mediaPlayer.stop();
                            StopPlayer();

                            File file = new File(listaPlayingNow.get(here).getArquivo());

                            mediaPlayer.stop();
                            
                            String source = null;

                            try {
                                source = file.toURI().toURL().toString();
                            } catch (Exception e) {
                            }

                            media = new Media(source);
                            playing = true;

                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        } finally {
                            music = listaPlayingNow.get(here);

                        }
                    }
                    break;
                case 2:
                case 3:
                    if (here == 0) {
                        here = listaPlayingNow.size();
                    } else {
                        here--;
                        try {

                            mediaPlayer.stop();
                            StopPlayer();

                            File file = new File(listaPlayingNow.get(here).getArquivo());

                            mediaPlayer.stop();
                           
                            String source = null;

                            try {
                                source = file.toURI().toURL().toString();
                            } catch (Exception e) {
                            }

                            media = new Media(source);

                            playing = true;
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        } finally {
                            music = listaPlayingNow.get(here);
                        }
                    }

                    break;
                case 4:
                    here = random.nextInt(listaPlayingNow.size());
                    try {
                        mediaPlayer.stop();
                        StopPlayer();

                        File file = new File(listaPlayingNow.get(here).getArquivo());

                        mediaPlayer.stop();
                        
                        String source = null;

                        try {
                            source = file.toURI().toURL().toString();
                        } catch (Exception e) {
                        }

                        media = new Media(source);

                        playing = true;
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    } finally {
                        music = listaPlayingNow.get(here);
                    }

                    break;
                case 5:
                    try {
                        mediaPlayer.stop();
                        StopPlayer();

                        File file = new File(listaPlayingNow.get(here).getArquivo());

                        mediaPlayer.stop();
                        
                        String source = null;

                        try {
                            source = file.toURI().toURL().toString();
                        } catch (Exception e) {
                        }

                        media = new Media(source);

                        playing = true;
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }

                    break;
                default:

                    break;
            }

        }
    }

    public void nextMediaPlayer() {
        if (listaPlayingNow != null) {
            int here = listaPlayingNow.indexOf(music);

            switch (mode) {
                case 1:
                    if (here + 1 == listaPlayingNow.size()) {
                        StopPlayer();
                    } else {
                        here++;
                        try {
                            mediaPlayer.stop();
                            StopPlayer();

                            File file = new File(listaPlayingNow.get(here).getArquivo());

                            mediaPlayer.stop();
                            
                            String source = null;

                            try {
                                source = file.toURI().toURL().toString();
                            } catch (Exception e) {
                            }

                            media = new Media(source);

                            playing = true;
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        } finally {
                            music = listaPlayingNow.get(here);

                        }
                    }
                    break;
                case 2:
                case 3:
                    if (here + 1 == listaPlayingNow.size()) {
                        here = 0;
                    } else {
                        here++;
                        try {
                            mediaPlayer.stop();
                            StopPlayer();

                            File file = new File(listaPlayingNow.get(here).getArquivo());

                            mediaPlayer.stop();
                            
                            String source = null;

                            try {
                                source = file.toURI().toURL().toString();
                            } catch (Exception e) {
                            }

                            media = new Media(source);

                            playing = true;
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        } finally {
                            music = listaPlayingNow.get(here);
                        }
                    }

                    break;
                case 4:
                    here = random.nextInt(listaPlayingNow.size());
                    try {
                        mediaPlayer.stop();
                        StopPlayer();

                        File file = new File(listaPlayingNow.get(here).getArquivo());

                        mediaPlayer.stop();
                        
                        String source = null;

                        try {
                            source = file.toURI().toURL().toString();
                        } catch (Exception e) {
                        }

                        media = new Media(source);

                        playing = true;
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    } finally {
                        music = listaPlayingNow.get(here);
                    }

                    break;
                case 5:
                    try {
                        mediaPlayer.stop();
                        StopPlayer();

                        File file = new File(listaPlayingNow.get(here).getArquivo());

                        mediaPlayer.stop();
                        
                        String source = null;

                        try {
                            source = file.toURI().toURL().toString();
                        } catch (Exception e) {
                        }

                        media = new Media(source);

                        playing = true;
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }

                    break;
                default:

                    break;
            }

        }
    }

    public int getMode() {
        return mode;
    }

    public void setMode(int mode) {
        if (mode >= 6) {
            mode = 1;
        }

        this.mode = mode;
        if (mode == 3) {
            Collections.shuffle(listaPlayingNow);
        } else {
            listaPlayingNow = oldListaPlayingNow;
        }
        System.out.println("mode: " + this.mode);
    }

    public List<Musica> getListaPlayingNow() {
        return listaPlayingNow;
    }

    public void setMusic(Musica music) throws IOException {
        this.music = music;
        mediaPlayer.stop();
        StopPlayer();

        File file = new File(music.getArquivo());

        mediaPlayer.stop();
        String source = null;

        try {
            source = file.toURI().toURL().toString();
        } catch (Exception e) {
        }

        media = new Media(source);

        playing = true;
    }

    public void setProgress(int millis) {
        Duration durat = Duration.millis(millis);
        mediaPlayer.seek(durat);
    }

    public double getProgress() {
        if (music == null) {
            return 100;
        } else {
            return mediaPlayer.getCurrentTime().toMillis();
        }
    }

    public double getTotalTime() {
        if (music == null) {
            return 100;
        } else {
            try {

                return mediaPlayer.getTotalDuration().toMillis();
            } catch (Exception ignored) {
                return 100;
            }
        }
    }

    private void StopPlayer() {
        mediaPlayer.stop();
        playing = false;
        //mediaPlayer.release();
    }

    public boolean isPlaying() {
        return playing;
    }
}
